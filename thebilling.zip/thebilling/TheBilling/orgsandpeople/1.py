from collections import Counter
s = "ostfaweri sileks xe :tis'b teet rhwnei 't srfee"
x = Counter(s)
print(x)