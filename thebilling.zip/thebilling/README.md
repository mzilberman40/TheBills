My billing system

Still in development
